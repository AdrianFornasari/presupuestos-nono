import type { ConfiguracionApp, Presupuesto } from '../types/presupuesto';
import {
  fechaHoraAhoraISO,
  fechaHoyISO,
  formatearNumeroPresupuesto,
} from '../utils/format';
import { db } from './appDb';

const PRIMER_NUMERO_PRESUPUESTO = 472;

interface DatosClientePresupuesto {
  clienteNombre: string;
  clienteDireccion: string;
  clienteTelefono: string;
}

async function calcularProximoNumero(
  configuracionExistente?: ConfiguracionApp,
): Promise<number> {
  const ultimoPresupuesto = await db.presupuestos.orderBy('numero').last();
  const siguientePorPresupuestos = ultimoPresupuesto
    ? ultimoPresupuesto.numero + 1
    : PRIMER_NUMERO_PRESUPUESTO;

  const siguienteConfigurado = configuracionExistente?.proximoNumero ?? 0;

  return Math.max(
    PRIMER_NUMERO_PRESUPUESTO,
    siguientePorPresupuestos,
    siguienteConfigurado,
  );
}

export async function obtenerOInicializarConfiguracion(): Promise<ConfiguracionApp> {
  const configuracionExistente = await db.configuracion.get('principal');
  const proximoNumero = await calcularProximoNumero(configuracionExistente);
  const ahora = fechaHoraAhoraISO();

  if (configuracionExistente) {
    if (configuracionExistente.proximoNumero !== proximoNumero) {
      const configuracionActualizada: ConfiguracionApp = {
        ...configuracionExistente,
        proximoNumero,
        actualizadoEn: ahora,
      };

      await db.configuracion.put(configuracionActualizada);
      return configuracionActualizada;
    }

    return configuracionExistente;
  }

  const configuracionInicial: ConfiguracionApp = {
    id: 'principal',
    proximoNumero,
    vendedor: 'CARLOS CENTENO',
    moneda: 'USD',
    tamanoTexto: 'muy-grande',
    creadoEn: ahora,
    actualizadoEn: ahora,
  };

  await db.configuracion.put(configuracionInicial);

  return configuracionInicial;
}

export async function listarPresupuestos(): Promise<Presupuesto[]> {
  const presupuestos = await db.presupuestos
    .orderBy('actualizadoEn')
    .reverse()
    .toArray();

  return presupuestos;
}

export async function obtenerPresupuestoPorId(
  id: string,
): Promise<Presupuesto | undefined> {
  return db.presupuestos.get(id);
}

export async function crearPresupuestoBorrador(): Promise<Presupuesto> {
  const ahora = fechaHoraAhoraISO();

  return db.transaction(
    'rw',
    db.presupuestos,
    db.configuracion,
    async () => {
      const configuracionExistente = await db.configuracion.get('principal');
      const numero = await calcularProximoNumero(configuracionExistente);

      const configuracion: ConfiguracionApp = configuracionExistente
        ? {
            ...configuracionExistente,
            proximoNumero: numero,
            actualizadoEn: ahora,
          }
        : {
            id: 'principal',
            proximoNumero: numero,
            vendedor: 'CARLOS CENTENO',
            moneda: 'USD',
            tamanoTexto: 'muy-grande',
            creadoEn: ahora,
            actualizadoEn: ahora,
          };

      await db.configuracion.put(configuracion);

      const numeroFormateado = formatearNumeroPresupuesto(numero);

      const nuevoPresupuesto: Presupuesto = {
        id: crypto.randomUUID(),
        numero,
        numeroFormateado,
        fechaEmision: fechaHoyISO(),

        clienteNombre: '',
        clienteDireccion: '',
        clienteTelefono: '',

        moneda: configuracion.moneda,
        vendedor: configuracion.vendedor,
        cotizacionUsdAl: '',

        subtotal: 0,
        total: 0,

        estado: 'borrador',
        estadoDrive: 'tablet',

        creadoEn: ahora,
        actualizadoEn: ahora,
      };

      await db.presupuestos.put(nuevoPresupuesto);

      await db.configuracion.update('principal', {
        proximoNumero: numero + 1,
        actualizadoEn: ahora,
      });

      return nuevoPresupuesto;
    },
  );
}

export async function actualizarDatosCliente(
  presupuestoId: string,
  datos: DatosClientePresupuesto,
): Promise<void> {
  await db.presupuestos.update(presupuestoId, {
    clienteNombre: datos.clienteNombre,
    clienteDireccion: datos.clienteDireccion,
    clienteTelefono: datos.clienteTelefono,
    estadoDrive: 'pendiente',
    actualizadoEn: fechaHoraAhoraISO(),
  });
}

export async function marcarPresupuestoEmitido(
  presupuestoId: string,
): Promise<void> {
  await db.presupuestos.update(presupuestoId, {
    estado: 'emitido',
    estadoDrive: 'pendiente',
    actualizadoEn: fechaHoraAhoraISO(),
  });
}
